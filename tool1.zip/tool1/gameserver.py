from http.server import BaseHTTPRequestHandler, HTTPServer
import random
import urllib.parse

hostName = "0.0.0.0"  # Makes the server available on all interfaces
serverPort = 8080

# Choices for Rock, Paper, Scissors
choices = ["rock", "paper", "scissors"]

class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        # Handle requests like "/play?choice=rock"
        if self.path.startswith('/play'):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            
            # Get the user's choice from the URL parameters
            if 'choice' in params:
                user_choice = params['choice'][0]
                if user_choice not in choices:
                    response = "Invalid choice. Please choose rock, paper, or scissors."
                else:
                    response = self.play_game(user_choice)
            else:
                response = "Please make a choice."

            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(bytes(response, "utf-8"))
            return

        # Default response is the game page
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

        # HTML game page
        html_content = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Rock Paper Scissors</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 50px;
                }
                .button {
                    display: inline-block;
                    margin: 10px;
                    padding: 20px 40px;
                    background-color: #4CAF50;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                    border: none;
                    border-radius: 5px;
                }
                .button:hover {
                    background-color: #45a049;
                }
                h1 {
                    font-size: 36px;
                    margin-bottom: 20px;
                }
                .result {
                    font-size: 24px;
                    margin-top: 20px;
                }
            </style>
        </head>
        <body>
            <h1>Rock, Paper, Scissors</h1>
            <p>Choose your move:</p>
            <button class="button" onclick="play('rock')">Rock</button>
            <button class="button" onclick="play('paper')">Paper</button>
            <button class="button" onclick="play('scissors')">Scissors</button>

            <div id="result" class="result"></div>

            <script>
                function play(choice) {
                    const url = `/play?choice=${choice}`;
                    fetch(url)
                        .then(response => response.text())
                        .then(result => {
                            document.getElementById('result').innerHTML = result;
                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });
                }
            </script>
        </body>
        </html>
        """
        
        self.wfile.write(bytes(html_content, "utf-8"))

    def play_game(self, user_choice):
        # Computer makes a random choice
        computer_choice = random.choice(choices)

        # Determine the result
        if user_choice == computer_choice:
            return f"It's a draw! Both chose {user_choice}."
        elif (user_choice == "rock" and computer_choice == "scissors") or \
             (user_choice == "scissors" and computer_choice == "paper") or \
             (user_choice == "paper" and computer_choice == "rock"):
            return f"You win! {user_choice} beats {computer_choice}."
        else:
            return f"You lose! {computer_choice} beats {user_choice}."

if __name__ == "__main__":
    # Create and start the server
    webServer = HTTPServer((hostName, serverPort), MyServer)
    print(f"Server started http://{hostName}:{serverPort}")

    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        pass

    webServer.server_close()
    print("Server stopped.")
